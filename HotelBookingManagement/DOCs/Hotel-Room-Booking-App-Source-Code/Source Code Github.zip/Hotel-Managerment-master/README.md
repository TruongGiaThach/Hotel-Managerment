# **Welcome to Hotel Booking Management App** 👋👋👋

***

## **1. Introduction** 📖📖📖

> * Contant the basic Management of a hotel Book room, Room Management, Income Management

## **2. Description** 🖋

> **a. Users:** 👥👥👥

> * Hotel employees.

> **b. Object:** 🎯🎯🎯

> * This program helps employees to management Hotel Room, Staff, Customer, income

> **c. Features:** 📋📋📋

> * Make and cancel the reservation

> * Room management

> * Income Management

> * Staff Management

> * Customer Management

## **3. Author** 👨‍💼👨‍💼👨‍💼

> **Leader:** Trương Gia Thạch.

> **Designer:** Nguyễn Tấn TIến.

> **Coder:** Nguyễn Văn Dũng.

## **3. Instructor information** 👨‍🏫

> MA. Nguyễn Tấn Toàn
